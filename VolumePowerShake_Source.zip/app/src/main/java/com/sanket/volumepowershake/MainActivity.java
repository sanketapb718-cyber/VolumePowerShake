package com.sanket.volumepowershake;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    public static final String PREFS = "vps_prefs";
    public static final String KEY_SHAKE = "shake_enabled";
    public static final String KEY_VOLUME = "volume_lock_enabled";
    public static final String KEY_SENSITIVITY = "sensitivity";

    private SharedPreferences prefs;
    private Switch volumeSwitch;
    private Switch shakeSwitch;
    private Spinner sensitivitySpinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);

        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(24));
        root.setBackgroundColor(Color.rgb(18, 18, 18));

        TextView title = text("Volume Power + Shake", 26, true);
        root.addView(title);

        TextView note = text(
                "\nUse Volume Up to lock the screen. If Android forwards the key while the screen is off, the app also attempts to wake it.\n\nShake-to-wake runs through a foreground service. OEM battery saving can stop it, so set this app to Unrestricted battery use.",
                15, false);
        root.addView(note);

        volumeSwitch = new Switch(this);
        volumeSwitch.setText("Volume Up = Lock / Wake helper");
        volumeSwitch.setTextColor(Color.WHITE);
        volumeSwitch.setTextSize(17);
        volumeSwitch.setChecked(prefs.getBoolean(KEY_VOLUME, true));
        root.addView(volumeSwitch, matchWrap());

        Button accessibilityBtn = button("OPEN ACCESSIBILITY SETTINGS");
        root.addView(accessibilityBtn, matchWrap());

        shakeSwitch = new Switch(this);
        shakeSwitch.setText("Enable Shake to Wake");
        shakeSwitch.setTextColor(Color.WHITE);
        shakeSwitch.setTextSize(17);
        shakeSwitch.setChecked(prefs.getBoolean(KEY_SHAKE, false));
        root.addView(shakeSwitch, matchWrap());

        TextView sensLabel = text("\nShake sensitivity", 16, true);
        root.addView(sensLabel);

        sensitivitySpinner = new Spinner(this);
        String[] levels = {"High", "Medium", "Low"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_dropdown_item, levels);
        sensitivitySpinner.setAdapter(adapter);
        String saved = prefs.getString(KEY_SENSITIVITY, "Medium");
        sensitivitySpinner.setSelection(saved.equals("High") ? 0 : saved.equals("Low") ? 2 : 1);
        root.addView(sensitivitySpinner, matchWrap());

        Button batteryBtn = button("OPEN BATTERY OPTIMIZATION SETTINGS");
        root.addView(batteryBtn, matchWrap());

        Button testBtn = button("TEST: LOCK SCREEN NOW");
        root.addView(testBtn, matchWrap());

        TextView footer = text(
                "\nIMPORTANT: Android normally does not give third-party apps full hardware Power-button privileges. Volume Up wake while the screen is fully off depends on your phone/OEM. Shake wake is the fallback.",
                13, false);
        footer.setTextColor(Color.LTGRAY);
        root.addView(footer);

        setContentView(root);

        volumeSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            prefs.edit().putBoolean(KEY_VOLUME, isChecked).apply();
        });

        shakeSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            prefs.edit().putBoolean(KEY_SHAKE, isChecked).apply();
            if (isChecked) {
                startShakeService();
                Toast.makeText(this, "Shake service started", Toast.LENGTH_SHORT).show();
            } else {
                stopService(new Intent(this, ShakeWakeService.class));
                Toast.makeText(this, "Shake service stopped", Toast.LENGTH_SHORT).show();
            }
        });

        sensitivitySpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                String value = position == 0 ? "High" : position == 2 ? "Low" : "Medium";
                prefs.edit().putString(KEY_SENSITIVITY, value).apply();
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });

        accessibilityBtn.setOnClickListener(v -> {
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            Toast.makeText(this, "Enable: Volume Power + Shake", Toast.LENGTH_LONG).show();
        });

        batteryBtn.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            } catch (Exception e) {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
            }
        });

        testBtn.setOnClickListener(v -> {
            if (VolumeAccessibilityService.instance != null) {
                VolumeAccessibilityService.instance.lockScreen();
            } else {
                Toast.makeText(this, "First enable Accessibility service", Toast.LENGTH_LONG).show();
            }
        });

        if (prefs.getBoolean(KEY_SHAKE, false)) {
            startShakeService();
        }
    }

    private void startShakeService() {
        Intent i = new Intent(this, ShakeWakeService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(i);
        } else {
            startService(i);
        }
    }

    private TextView text(String s, int sp, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(Color.WHITE);
        t.setTextSize(sp);
        if (bold) t.setTypeface(null, android.graphics.Typeface.BOLD);
        return t;
    }

    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(15);
        return b;
    }

    private LinearLayout.LayoutParams matchWrap() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(10);
        return p;
    }

    private int dp(int n) {
        return (int) (n * getResources().getDisplayMetrics().density);
    }
}
