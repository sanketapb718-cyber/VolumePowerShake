VOLUME POWER + SHAKE — SOURCE PROJECT

Features
--------
1. Volume Up = lock screen while the display is on.
2. If Android forwards Volume Up while the display is off, the app attempts to wake it.
3. Shake-to-wake using the accelerometer + foreground service.
4. High / Medium / Low shake sensitivity.
5. Start shake service after reboot.
6. Battery optimization settings shortcut.

Important Android limitation
----------------------------
A normal non-root Android app cannot become a true hardware Power button.
Many phones do NOT forward volume-key events to third-party apps while the
screen is fully off. Therefore Volume Up wake is best-effort. Shake-to-wake
is included as the fallback, but aggressive OEM battery saving can also stop
background sensor delivery.

After installing the APK
------------------------
1. Open the app.
2. Tap OPEN ACCESSIBILITY SETTINGS.
3. Enable "Volume Power + Shake".
4. Turn on "Enable Shake to Wake".
5. Open battery settings and set the app to Unrestricted / Don't optimize.
6. Test lock and shake wake.
